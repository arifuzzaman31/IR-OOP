$(function () {
    $('.select_2').select2({
        placeholder: 'Select an option',
        multiple: true,
    });
});
