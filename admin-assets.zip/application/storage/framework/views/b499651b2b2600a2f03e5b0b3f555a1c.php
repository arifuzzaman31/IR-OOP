

<?php $__env->startSection('content'); ?>
<div class="section m-4">
    <div class="widget widget-table-two">
        <div class="widget-heading">
            <h5 class=""><?php echo e($page_title); ?></h5>
        </div>
        <div class="widget-body">
            <div class="table-responsive">
                <table class="table table-striped datatable datatable_custom">
                    <thead>
                        <tr>
                            <th>
                                <div class="th-content text-left">ID</div>
                            </th>
                            <th>
                                <div class="th-content">Category</div>
                            </th>
                            <th>
                                <div class="th-content text-left"></div>
                            </th>
                            <th>
                                <div class="th-content text-left">Title</div>
                            </th>
                            <?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 2): ?>
                            <th>
                                <div class="th-content text-left">Jury</div>
                            </th>
                            <?php endif; ?>
                            <th>
                                <div class="th-content text-left">Deadline</div>
                            </th>
                            <th>
                                <div class="th-content text-left">Status</div>
                            </th>
                            <th>
                                <div class="th-content">Action</div>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $count = 1;
                        ?>
                        <?php $__currentLoopData = $circular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $deadlineDate = date('Y-m-d', strtotime($item['deadline']));
                        $currentDate = date('Y-m-d');

                        $expired_check = ($currentDate > $deadlineDate) ? true : false;
                        $submission_check = App\Models\Ebook::where(['circular_id'=> $item->id, 'author_id'=> Auth::user()->id])->count() > 0 ? true : false;
                        ?>
                        <tr>
                            <td class="text-left"><?php echo e($count++); ?></td>
                            <td><?php echo e($item['template_mave']?->title); ?></td>
                            <td class="text-left">
                                <img src="<?php echo e(url('/media/' . ($item->cover_image_mave ? $item->cover_image_mave?->file_name : 'default_broken.jpg'))); ?>"
                                    class="rounded" alt="Responsive image" alt="" width="150px">
                            </td>
                            <td class="text-left">
                                <div class="d-flex align-items-center"><?php echo e($item['title']); ?></div>
                            </td>
                            <?php if((Auth::user()->role_id == 1 || Auth::user()->role_id == 2) && !empty($item->jury_members_mave)): ?>
                            <td>
                                <?php $__currentLoopData = $item->jury_members_mave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jury_mave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="#" class="text-danger remove_jury_member"
                                    data-action_type="remove" data-ebook_id="<?php echo e($item->id); ?>"
                                    data-jury_id="<?php echo e($jury_mave->id); ?>" title="Remove Jury">
                                    <i class="fa fa-trash"></i>
                                </a>
                                <span>
                                    <?php echo e($jury_mave->firstname . ' ' . $jury_mave->lastname); ?>

                                </span>
                                <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <?php endif; ?>
                            <td><?php echo e($expired_check == false ? date('d-m-Y', strtotime($item['deadline'])) : ''); ?></td>

                            <td class="text-left">
                                <?php if($expired_check == false && $submission_check == false && Auth::user()->role_id != 3 && $item['status'] == 1): ?>
                                <a href="<?php echo e(url('admin/circular_ebook/create/' . $item->template_mave?->slug . '/' . $item['slug'])); ?>"
                                    class="badge badge-pill badge-success" role="button" title="Write Ebook">
                                    Write
                                </a>
                                <?php elseif($submission_check == true): ?>
                                <span class="badge badge-pill badge-warning">Submitted</span>
                                <?php elseif($expired_check == true): ?>
                                <span class="badge badge-pill badge-danger">Expired</span>
                                <?php else: ?>
                                <!-- <span class="badge badge-pill badge-danger"></span> -->
                                <?php endif; ?>
                            </td>
                            <td class="action_btn">
                                <?php if($expired_check == false && (Auth::user()->role_id == 1 || Auth::user()->role_id == 2)): ?>
                                <a href="#" class="btn btn-info add_jury_member" role="button"
                                    title="Add Jury" data-toggle="modal" data-target="#juryMemberAdd"
                                    data-templete-title="<?php echo e($item->title); ?>"
                                    data-ebook-id="<?php echo e($item->id); ?>">
                                    <i class="fa fa-user-plus" aria-hidden="true"></i>
                                </a>
                                <a href="<?php echo e(url('admin/circular_edit/') . '/' . $item['id']); ?>"
                                    class="btn btn-warning" role="button" title="Edit">
                                    <i class="fa fa-pencil" aria-hidden="true"></i>
                                </a>
                                <a href="<?php echo e(url('admin/circular_delete/') . '/' . $item['slug']); ?>"
                                    onclick="return confirm('Delete item?')" class="btn btn-danger"
                                    role="button" title="View">
                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="juryMemberAdd" data-backdrop="static" data-keyboard="false" tabindex="-1"
    aria-labelledby="juryMemberAddLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="juryMemberAddLabel">Add Jury</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Add Member</label>
                            <select class="form-control" name="member_id" id="member_id">
                                <option value="">Select Any</option>
                                <?php $__currentLoopData = $jury_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jury): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($jury->id); ?>">
                                    <?php echo e($jury->firstname . ' ' . $jury->lastname); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" name="" value="0" id="ebook_id">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="add_new_jury" data-action_type="add">Save</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<!-- Add or Remove Jury Member -->
<script>
    $(document).on('click', '.add_jury_member', function(e) {
        e.preventDefault();
        $('#juryMemberAddLabel').text('Templete: ' + $(this).attr('data-templete-title'));
        $('#ebook_id').val($(this).attr('data-ebook-id'));
    });

    $(document).on('click', '#add_new_jury, .remove_jury_member', async function(e) {
        e.preventDefault();
        let data = {};
        let action_type = $(this).attr('data-action_type');
        let URL = "<?php echo e(url('admin/circular_update_jury/')); ?>" + '/' + action_type;

        if (action_type == "remove") {
            data = {
                ebook_id: $(this).attr('data-ebook_id'),
                member_id: $(this).attr('data-jury_id')
            }
        }

        if (action_type == "add") {
            data = {
                ebook_id: $('#ebook_id').val(),
                member_id: $('#member_id').val()
            }
            $('#juryMemberAdd').modal('toggle');
        }


        let response = await custom_ajax('POST', URL, data);
        if (response.status == 200) {
            alert('Jury Updated Successfully!...');
        } else {
            alert('Something went wrong! Please try again later');
        }

    });
</script>
<?php $__env->stopPush(); ?>



<!-- Pending, Processing, Reviewed, Published, Draft, Revision -->
<!-- Pending, Processing, Published, Canceled -->
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ethersta/ebook.etherstaging.xyz/application/resources/views/pages/circular/circular_list.blade.php ENDPATH**/ ?>