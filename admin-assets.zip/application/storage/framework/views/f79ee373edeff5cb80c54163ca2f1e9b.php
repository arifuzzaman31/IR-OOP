<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($publication['title']); ?></title>
</head>

<?php ($exclude_items=["template_id", "_token", "ebook_title", "ebook_author_name", "ebook_date", "templete_type", "type", "cover_image_id", "circular_id", "submission_type", "method", "slug"]); ?>
<?php ($cover_image = ($publication->cover_image_mave) ? $publication->cover_image_mave->file_path :'media/default_broken.jpg'); ?>

<body>
    <section style="page-break-inside:avoid;">
        <h2>Title: <?php echo e($publication['title']); ?></h2>
        <img src="<?php echo e(url( $cover_image)); ?>" alt="Featured Image" height="75%" width="100%">
        <h3>Author: <?php echo e($publication['author_name']); ?></h3>
        <h3>Category: <?php echo e($publication['templates_mave']->title); ?></h3>
        <h3>Date: <?php echo e($publication['form_data']['ebook_date']); ?></h3>
    </section>

    <div style="page-break-before:always">&nbsp;</div> 


    <!-- <img src="<?php echo e(url( $cover_image)); ?>" alt="Featured Image" height="250px" width="250px"> -->
    <!--<img src="<?php echo e(url('media/mave_1SO3Ge.jpg')); ?>" alt="Featured Image" height="250px" width="250px">-->

    <!--<h2>Title: <?php echo e(url('/') .'/' .(($publication->cover_image_mave) ? $publication->cover_image_mave->file_path :'media/default_broken.jpg')); ?></h2> -->
    <!--<h2>Image: <?php echo e(url('media/mave_1SO3Ge.jpg')); ?></h2> -->
    <!--<h2>Title: <?php echo e($publication['title']); ?></h2>-->

    <?php $__currentLoopData = $publication['form_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $form_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(!in_array($key, $exclude_items)): ?>
    <h4><?php echo e(CustomHelper::abbr_to_full_state($key)); ?></h4>
    <p><?php echo e($form_data); ?></p>
    <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>

</html><?php /**PATH /home/ethersta/ebook.etherstaging.xyz/application/resources/views/pages/pdf/publication_templete.blade.php ENDPATH**/ ?>