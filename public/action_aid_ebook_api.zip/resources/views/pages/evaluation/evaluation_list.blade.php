@extends('layout.app')

@section('content')
<div class="section m-4">
    <div class="widget widget-table-two">
        <div class="widget-heading row">
            <div class="col-md-8">
                <h5 class="">Ebook Evaluation: {{ $ebook->title }}</h5>
            </div>
            <div class="col-md-4 text-right">
                <h6>Category: {{ $ebook_templete?->title }}</h6>
            </div>
        </div>
        <div class="widget-body">
            <div class="table-responsive">
                <table class="table table-striped datatable datatable_custom">
                    <thead>
                        <tr>
                            <th class="text-left">
                                <div class="th-content">ID</div>
                            </th>
                            <th>
                                <div class="th-content">Date</div>
                            </th>
                            <th>
                                <div class="th-content">Jury</div>
                            </th>
                            <th>
                                <div class="th-content text-center">Total Mark</div>
                            </th>
                            <th>
                                <div class="th-content text-left">Evaluation</div>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($evaluations as $item)
                        <tr>
                            <td class="text-left">{{ $item['id'] }}</td>
                            <td>{{ date("d-m-Y", strtotime($item['created_at']));  }}</td>
                            <td>{{ $item['jury_mave']?->firstname . ' ' . $item['jury_mave']?->lastname }}</td>
                            <td class="text-center">{{ $item['total_mark'] }}</td>
                            <td class="text-left">
                                @foreach($item['evaluation'] as $eval)
                                @foreach($ebook_templete_structure as $stu_item)
                                @if($stu_item['form_name'] ==$eval['field'])
                                <p class="ebook_evaluation_title" data-eval-field="{{ $eval['field'] }}">
                                    {{ $stu_item['evaluation_query'] }}
                                </p>
                                <p>Mark: {{$eval['ebook_mark'] .' out of '. $stu_item['mark'] }}</p>
                                @endif
                                @endforeach
                                <p>Comment: {{$eval['ebook_comment']}}</p>
                                <br>
                                @endforeach
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


@endsection