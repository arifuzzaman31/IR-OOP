<div class="widget-content">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>
                        <div class="th-content">PostID</div>
                    </th>
                    <th>
                        <div class="th-content">Employee</div>
                    </th>
                    <th>
                        <div class="th-content">Post Title</div>
                    </th>
                    <th>
                        <div class="th-content">CreatedAt</div>
                    </th>
                    <th>
                        <div class="th-content">Status</div>
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>8</td>
                    <td>Nawal Shreya</td>
                    <td>post title here</td>
                    <td class="text-center">29 Oct, 2023</td>
                    <td> Pending </td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>OIKOKOK</td>
                    <td>post title here</td>
                    <td class="text-center">25 Oct, 2023</td>
                    <td> Pending </td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Mojumde</td>
                    <td>post title here</td>
                    <td class="text-center">24 Oct, 2023</td>
                    <td> Pending </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
