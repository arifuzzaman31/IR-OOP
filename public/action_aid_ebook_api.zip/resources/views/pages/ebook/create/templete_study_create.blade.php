@extends('layout.app')

@section('content')
<div class="section m-4 ebook_create_form">
    <div class="widget widget-table-two">
        <div class="widget-heading">
            <h5 class="">{{ $page_title }}</h5>
        </div>
        <div class="widget-body">
            <form id="cf-form" action="{{url('/admin/ebook_store/')}}">
                @csrf
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group custom_upload_files">
                            <label>Cover Image </label>
                            <input type="file" class="form-control" name="cover_image" id="upload_files">
                        </div>
                    </div>
                    <div class="col-md-6 row">
                        <div class="col-md-12">
                            <label for="ebook_title">Study Title (15-20 Words)</label>
                            <input type="text" class="form-control" id="ebook_title" name="ebook_title" placeholder="" value="" required="" max_length="">
                        </div>
                        <div class="col-md-12">
                            <label for="ebook_author_name">Name of Author</label>
                            <input type="text" class="form-control" id="ebook_author_name" name="ebook_author_name" placeholder="" value="" required="">
                        </div>
                        <div class="col-md-12">
                            <label for="ebook_date">Date</label>
                            <input type="date" class="form-control" id="ebook_date" name="ebook_date" placeholder="" value="" required="">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 mb-2">
                        <label for="ebook_abstract">Abstract (200 Word)</label>
                        <textarea class="form-control" name="ebook_abstract" id="ebook_abstract" cols="30" rows="10" max_length="200"></textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="ebook_intro">Introduction and Objective (200 Word)</label>
                        <textarea class="form-control" name="ebook_intro" id="ebook_intro" cols="30" rows="10" max_length="200"></textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="ebook_literature_review">Literature Review (500 Word)</label>
                        <textarea class="form-control" name="ebook_literature_review" id="ebook_literature_review" cols="30" rows="10" max_length="200"></textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="ebook_method">Methodology (300 Word)</label>
                        <textarea class="form-control" name="ebook_method" id="ebook_method" cols="30" rows="10"></textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="ebook_rd">Results & Discussions (2000 Word)</label>
                        <textarea class="form-control" name="ebook_rd" id="ebook_rd" cols="30" rows="10"></textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="ebook_cr">Conclusion and Recommendations (300 Word)</label>
                        <textarea class="form-control" name="ebook_cr" id="ebook_cr" cols="30" rows="10"></textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="ebook_reference">Reference (500 Word)</label>
                        <textarea class="form-control" name="ebook_reference" id="ebook_reference" cols="30" rows="10"></textarea>
                    </div>
                    <div class="col-md-12 text-right">
                        <input type="hidden" name="type" value="{{ $type }}">
                        <input type="hidden" name="template_id" value="{{ $template_id }}">
                        <input type="hidden" name="templete_type" value="{{ $templete_type }}">
                        <button class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

@include('partial_inner.partial_ebook_create', $templete)
@endsection