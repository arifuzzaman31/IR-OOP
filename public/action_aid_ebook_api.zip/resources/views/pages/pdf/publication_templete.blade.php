<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $publication['title'] }}</title>
</head>

<body>

    <img src="{{ public_path('media\mave_1SO3Ge.jpg')  }}" alt="Featured Image" height="100px" width="100px">
    <!-- <h2>Title: {{ url('/') .'/' .(($publication->cover_image_mave) ? $publication->cover_image_mave->file_path :'media/default_broken.jpg')  }}</h2> -->
    <!-- <h2>Title: {{ public_path('media\mave_1SO3Ge.jpg') }}</h2> -->
    <h2>Title: {{ $publication['title'] }}</h2>
    <h3>Author: {{ $publication['author_name'] }}</h3>
    <!-- <h3>Author: {{ $publication['author_name'] }}</h3> -->
    <h3>Date: {{ $publication['form_data']['ebook_date'] }}</h3>

    @foreach ( $publication['form_data'] as $key => $form_data )
    <h4>{{ CustomHelper::abbr_to_full_state($key) }}</h4>
    <p>{{ $form_data }}</p>
    @endforeach
</body>

</html>