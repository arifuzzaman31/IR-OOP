@push('script')
<script>
    $(document).ready(function(e) {
        // let templete_structure = "{{ $templete }}";
        console.log("yahooo.com");
    });
</script>
@endpush