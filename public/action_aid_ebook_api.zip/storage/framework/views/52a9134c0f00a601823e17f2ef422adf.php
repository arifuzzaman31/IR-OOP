

<?php $__env->startSection('content'); ?>
<div class="section m-4">
    <div class="widget widget-table-two">
        <div class="widget-heading">
            <h5 class=""><?php echo e($page_title); ?></h5>
        </div>
        <div class=" widget-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Cover Image</label>
                        <div class="bg-ash rounded text-center p-2">
                            <img class="img-fluid rounded p-4" src="<?php echo e(asset('/') .(($ebook->cover_image_mave) ? $ebook->cover_image_mave->file_path :'media/default_broken.jpg')); ?>" width="100%" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-md-6 row">
                    <div class="col-md-12">
                        <label for="ebook_title">Study Title</label>
                        <input type="text" class="form-control custom_form_input readonly-bg-white" id="ebook_title" name="ebook_title" placeholder="">
                    </div>
                    <div class="col-md-12">
                        <label for="ebook_author_name">Name of Author</label>
                        <input type="text" class="form-control custom_form_input readonly-bg-white" id="ebook_author_name" name="ebook_author_name" placeholder="" value="">
                    </div>
                    <div class="col-md-12">
                        <label for="ebook_date">Date</label>
                        <input type="date" class="form-control custom_form_input readonly-bg-white" id="ebook_date" name="ebook_date" placeholder="" value="" required="">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mb-2">
                    <label for="introduction">Introduction/Background</label>
                    <textarea class="form-control custom_form_input readonly-bg-white" name="introduction" id="introduction" cols="30" rows="10"></textarea>
                </div>
                <div class="col-md-12 mb-2">
                    <label for="problem_solution">Problem & Solution</label>
                    <textarea class="form-control custom_form_input readonly-bg-white" name="problem_solution" id="problem_solution" cols="30" rows="10"></textarea>
                </div>
                <div class="col-md-12 mb-2">
                    <label for="organization_contribution">Organization contribution</label>
                    <textarea class="form-control custom_form_input readonly-bg-white" name="organization_contribution" id="organization_contribution" cols="30" rows="10"></textarea>
                </div>
                <div class="col-md-12 mb-2">
                    <label for="community_contribution">Community Contribution</label>
                    <textarea class="form-control custom_form_input readonly-bg-white" name="community_contribution" id="community_contribution" cols="30" rows="10"></textarea>
                </div>
                <div class="col-md-12 mb-2">
                    <label for="sustain_success">Sustainability of success </label>
                    <textarea class="form-control custom_form_input readonly-bg-white" name="sustain_success" id="sustain_success" cols="30" rows="10"></textarea>
                </div>
                <div class="col-md-12 mb-2">
                    <label for="participants_quotes">Participants Quotes </label>
                    <textarea class="form-control custom_form_input readonly-bg-white" name="participants_quotes" id="participants_quotes" cols="30" rows="10"></textarea>
                </div>
                <div class="col-md-12 mb-2">
                    <label for="action_photo">Action Photo</label>
                    <textarea class="form-control custom_form_input readonly-bg-white" name="action_photo" id="action_photo" cols="30" rows="10"></textarea>
                </div>
                <div class="col-md-12 text-right">
                    <button class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
        </form>
        <div id="cf-response-message"></div>

    </div>


</div>


<!-- Rate Now Modal -->
<div class="modal fade" id="modal_rate_now" tabindex="-1" role="dialog" aria-labelledby="rate_now_label" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?php echo e(url('admin/ebook_status_update/')); ?>" id="cf-form" method="POST">
                <!-- <?php echo csrf_field(); ?> -->
                <div class="modal-header">
                    <h5 class="modal-title" id="rate_now_label">Feedback</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h4 class="rating_query" id="rating_query">Do you think this image is okay?</h4>
                    <div class="form-group">
                        <label for="change_status">Comment / Evaluation</label>
                        <textarea class="form-control" name="ebook_comment" id="ebook_comment" cols="30" rows="10"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="ebook_mark">Rating</label>
                        <select class="form-control" name="ebook_mark" id="ebook_mark">
                            <option value="0">Select</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="ebook_id" id="ebook_id" value="<?php echo e($ebook->id); ?>">
                    <input type="hidden" name="jury_id" id="jury_id" value="<?php echo e(Auth::user()->id); ?>">
                    <input type="hidden" name="ebook_field_name" id="ebook_field_name" value="">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" id="update_feedback" class="btn btn-primary">Save</button>
                </div>
            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
<script>
    let ebook = <?php echo json_encode($ebook, 15, 512) ?>;
    $(document).ready(function(e) {
        let output_fields = $('.custom_form_input');

        // console.log(ebook);
        $.each(output_fields, function(key, field) {
            // field.val(key);
            // field.val("Hello World");
            // console.log($(field).val("Hello World"));

            let field_name = $(field).attr('name');
            $(field).val(ebook.form_data[field_name]).attr('readonly', 'true');

            $(field).before(`<a href="#" class="btn btn-sm btn-primary float-right rate_now mb-2" data-toggle="modal" data-target="#modal_rate_now" data-field_name="${field_name}">Rate</a>`)

            // console.log(ebook.form_data[field_name]);
        });

    });

    $(document).on('click', '.rate_now', function(e) {
        let field_name = $(this).attr('data-field_name');
        let template_structure = ebook.templates_mave.structure;
        // let template_structure = JSON.parse(ebook.templates_mave.structure);

        // console.log(template_structure);
        $('#ebook_field_name').val(field_name);
        let stucture_item = template_structure.find((item) => {
            if (item.form_name == field_name) {
                return item;
            }
        });

        // console.log(field_name);
        // console.log(template_structure);

        $('#rating_query').text(stucture_item.evaluation_query);

        let dynamic_option = '';
        let i = 1;
        if (stucture_item.mark != null) {
            while (i <= stucture_item.mark) {
                dynamic_option += `<option value="${i}">${i}</option> `;
                i++;
            }

            $('#ebook_mark').empty().html(dynamic_option);
        }
    });
</script>



<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Projects\Laravel\action_aid_ebook_api\resources\views/pages/feedback/create_case_study.blade.php ENDPATH**/ ?>