<?php $__env->startSection('content'); ?>
<div class="section m-4">
    <div class="widget widget-table-two">
        <div class="widget-heading">
            <h5 class=""><?php echo e($page_title); ?></h5>
        </div>

        <div class="widget-body">
            <form id="cf-form" action="<?php echo e(url('/admin/ebook_store/')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <label for="ebook_title">Name of Idea</label>
                        <input type="text" class="form-control" id="ebook_title" name="ebook_title" placeholder="" value="" required="">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label for="ebook_author_name">Name of Author</label>
                        <input type="text" class="form-control" id="ebook_author_name" name="ebook_author_name" placeholder="" value="" required="">
                    </div>
                    <div class="col-md-6">
                        <label for="ebook_date">Date</label>
                        <input type="date" class="form-control" id="ebook_date" name="ebook_date" placeholder="" value="" required="">
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="problem">What is the problem?</label>
                        <textarea class="form-control" name="problem" id="problem" cols="30" rows="10"> </textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="why_innovative">Why is it innovative?</label>
                        <textarea class="form-control" name="why_innovative" id="why_innovative" cols="30" rows="10"> </textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="participants">Who are the participants?</label>
                        <textarea class="form-control" name="participants" id="participants" cols="30" rows="10"> </textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="how_work">How it will work?</label>
                        <textarea class="form-control" name="how_work" id="how_work" cols="30" rows="10"> </textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="look_like">What will it look like? </label>
                        <textarea class="form-control" name="look_like" id="look_like" cols="30" rows="10"> </textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="benifits_participants">What is the benefit for the participants? </label>
                        <textarea class="form-control" name="benifits_participants" id="benifits_participants" cols="30" rows="10"> </textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="benefit_organization">What is the benefit for the organization?</label>
                        <textarea class="form-control" name="benefit_organization" id="benefit_organization" cols="30" rows="10"> </textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="scale_up">How can be sustainable of your idea or scale up?</label>
                        <textarea class="form-control" name="scale_up" id="scale_up" cols="30" rows="10"> </textarea>
                    </div>
                    <div class="col-md-12 text-right">
                        <input type="hidden" name="type" value="<?php echo e($type); ?>">
                        <input type="hidden" name="template_id" value="<?php echo e($template_id); ?>">
                        <input type="hidden" name="templete_type" value="<?php echo e($templete_type); ?>">
                        <button class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Projects\Laravel\action_aid_ebook_api\resources\views/pages/ebook/create/templete_innovative_idea.blade.php ENDPATH**/ ?>