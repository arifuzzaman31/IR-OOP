<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($publication['title']); ?></title>
</head>

<body>

    <img src="<?php echo e(public_path('media\mave_1SO3Ge.jpg')); ?>" alt="Featured Image" height="100px" width="100px">
    <!-- <h2>Title: <?php echo e(url('/') .'/' .(($publication->cover_image_mave) ? $publication->cover_image_mave->file_path :'media/default_broken.jpg')); ?></h2> -->
    <!-- <h2>Title: <?php echo e(public_path('media\mave_1SO3Ge.jpg')); ?></h2> -->
    <h2>Title: <?php echo e($publication['title']); ?></h2>
    <h3>Author: <?php echo e($publication['author_name']); ?></h3>
    <!-- <h3>Author: <?php echo e($publication['author_name']); ?></h3> -->
    <h3>Date: <?php echo e($publication['form_data']['ebook_date']); ?></h3>

    <?php $__currentLoopData = $publication['form_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $form_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h4><?php echo e(CustomHelper::abbr_to_full_state($key)); ?></h4>
    <p><?php echo e($form_data); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>

</html><?php /**PATH I:\Projects\Laravel\action_aid_ebook_api\resources\views/pages/pdf/publication_templete.blade.php ENDPATH**/ ?>