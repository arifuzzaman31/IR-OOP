

<?php $__env->startSection('content'); ?>
<div class="section m-4">
    <div class="widget widget-table-two">
        <div class="widget-heading row">
            <div class="col-md-8">
                <h5 class="">Ebook Evaluation: <?php echo e($ebook->title); ?></h5>
            </div>
            <div class="col-md-4 text-right">
                <h6>Category: <?php echo e($ebook_templete?->title); ?></h6>
            </div>
        </div>
        <div class="widget-body">
            <div class="table-responsive">
                <table class="table table-striped datatable datatable_custom">
                    <thead>
                        <tr>
                            <th class="text-left">
                                <div class="th-content">ID</div>
                            </th>
                            <th>
                                <div class="th-content">Date</div>
                            </th>
                            <th>
                                <div class="th-content">Jury</div>
                            </th>
                            <th>
                                <div class="th-content text-center">Total Mark</div>
                            </th>
                            <th>
                                <div class="th-content text-left">Evaluation</div>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-left"><?php echo e($item['id']); ?></td>
                            <td><?php echo e(date("d-m-Y", strtotime($item['created_at']))); ?></td>
                            <td><?php echo e($item['jury_mave']?->firstname . ' ' . $item['jury_mave']?->lastname); ?></td>
                            <td class="text-center"><?php echo e($item['total_mark']); ?></td>
                            <td class="text-left">
                                <?php $__currentLoopData = $item['evaluation']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $ebook_templete_structure; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($stu_item['form_name'] ==$eval['field']): ?>
                                <p class="ebook_evaluation_title" data-eval-field="<?php echo e($eval['field']); ?>">
                                    <?php echo e($stu_item['evaluation_query']); ?>

                                </p>
                                <p>Mark: <?php echo e($eval['ebook_mark'] .' out of '. $stu_item['mark']); ?></p>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <p>Comment: <?php echo e($eval['ebook_comment']); ?></p>
                                <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Projects\Laravel\action_aid_ebook_api\resources\views/pages/evaluation/evaluation_list.blade.php ENDPATH**/ ?>