<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(e) {
        // let templete_structure = "<?php echo e($templete); ?>";
        console.log("yahooo.com");
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH I:\Projects\Laravel\action_aid_ebook_api\resources\views/partial_inner/partial_ebook_create.blade.php ENDPATH**/ ?>