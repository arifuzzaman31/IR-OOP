<?php $__env->startSection('content'); ?>
<div class="section m-4">
    <div class="widget widget-table-two">
        <div class="widget-heading">
            <h5 class=""><?php echo e($page_title); ?></h5>
        </div>
        <form id="cf-form" action="<?php echo e(url('/admin/ebook_store/')); ?>">
            <?php echo csrf_field(); ?>
            <div class=" widget-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group custom_upload_files">
                            <label>Cover Image </label>
                            <input type="file" class="form-control" name="cover_image" id="upload_files">
                        </div>
                    </div>
                    <div class="col-md-6 row">
                        <div class="col-md-12">
                            <label for="ebook_title">Study Title</label>
                            <input type="text" class="form-control" id="ebook_title" name="ebook_title" placeholder="" value="" required="">
                        </div>
                        <div class="col-md-12">
                            <label for="ebook_author_name">Name of Author</label>
                            <input type="text" class="form-control" id="ebook_author_name" name="ebook_author_name" placeholder="" value="" required="">
                        </div>
                        <div class="col-md-12">
                            <label for="ebook_date">Date</label>
                            <input type="date" class="form-control" id="ebook_date" name="ebook_date" placeholder="" value="" required="">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 mb-2">
                        <label for="introduction">Introduction/Background</label>
                        <textarea class="form-control" name="introduction" id="introduction" cols="30" rows="10"></textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="problem_solution">Problem & Solution</label>
                        <textarea class="form-control" name="problem_solution" id="problem_solution" cols="30" rows="10"></textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="organization_contribution">Organization contribution</label>
                        <textarea class="form-control" name="organization_contribution" id="organization_contribution" cols="30" rows="10"></textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="community_contribution">Community Contribution</label>
                        <textarea class="form-control" name="community_contribution" id="community_contribution" cols="30" rows="10"></textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="sustain_success">Sustainability of success </label>
                        <textarea class="form-control" name="sustain_success" id="sustain_success" cols="30" rows="10"></textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="participants_quotes">Participants Quotes </label>
                        <textarea class="form-control" name="participants_quotes" id="participants_quotes" cols="30" rows="10"></textarea>
                    </div>
                    <div class="col-md-12 mb-2">
                        <label for="action_photo">Action Photo</label>
                        <textarea class="form-control" name="action_photo" id="action_photo" cols="30" rows="10"></textarea>
                    </div>
                    <div class="col-md-12 text-right">
                        <input type="hidden" name="type" value="<?php echo e($type); ?>">
                        <input type="hidden" name="template_id" value="<?php echo e($template_id); ?>">
                        <input type="hidden" name="templete_type" value="<?php echo e($templete_type); ?>">
                        <button class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </div>
        </form>
        <div id="cf-response-message"></div>

    </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Projects\Laravel\action_aid_ebook_api\resources\views/pages/ebook/create/templete_case_story.blade.php ENDPATH**/ ?>