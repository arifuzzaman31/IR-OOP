

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin-assets/lib/css/min.css')); ?>">
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
<div class="section m-4">
    <div class="widget widget-table-two">
        <div class="widget-heading">
            <h5 class=""><?php echo e($page_title); ?></h5>
        </div>
        <div class="widget-body">
            <div id="flipbookContainer">
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>

<!-- Flipbook main Js file -->
<script src="<?php echo e(asset('admin-assets/lib/js/dflip.min.js')); ?> " type="text/javascript"></script>
<!-- Flipbook main Js file -->
<script>
    $(document).ready(function() {
        //uses source from online(make sure the file has CORS access enabled if used in cross-domain)
        // var pdf = 'http://localhost:8000/admin/publication/generate_pdf/4461712031255';
        // var pdf = ''https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf'';
        var pdf = "<?php echo e(url('admin/publication/generate_pdf/' .$publication->slug)); ?>";
        var options = {
            // height: 1500,
            duration: 200,
            backgroundColor: "#dbdada"
        };
        var flipBook = $("#flipbookContainer").flipBook(pdf, options);
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Projects\Laravel\action_aid_ebook_api\resources\views/pages/publication/publication_view.blade.php ENDPATH**/ ?>