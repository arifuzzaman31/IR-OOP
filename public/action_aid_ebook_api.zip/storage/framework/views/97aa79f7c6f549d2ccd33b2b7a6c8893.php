

<?php $__env->startSection('content'); ?>
<div class="section m-4">
    <div class="widget widget-table-two">
        <div class="widget-heading">
            <h5 class=""><?php echo e($page_title); ?></h5>
        </div>
        <div class="widget-body">
            <form action="<?php echo e(url('admin/user/store')); ?>" method="POSt" id="cf-form">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <!-- <div class="form-group custom_upload_files">
                            <label>Profile Picture </label>
                            <input type="file" class="form-control" name="profile_picture" id="upload_files">
                        </div> -->

                        <?php echo $__env->make('partials.upload_files', ['label' => "Profile Picture" , 'name' =>"profile_picture_id", 'value'=>'', 'multiple' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-md-6 row">
                        <div class="col-md-12">
                            <label for="firstname">First Name</label>
                            <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Enter First Name" value="" required="">
                        </div>
                        <div class="col-md-12">
                            <label for="lastname">Last Name</label>
                            <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Enter Last Name" value="" required="">
                        </div>
                        <div class="col-md-12">
                            <label for="phone">Phone</label>
                            <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Phone Number" value="">
                        </div>
                        <div class="col-md-12">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email Address" value="" required="">
                        </div>
                        <div class="col-md-12">
                            <label for="role">Role</label>
                            <select class="form-control" name="role_id" id="role_id">
                                <option value="">Select Role</option>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label for="password">New Password</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Enter New password" value="" required="">
                        </div>
                        <div class="col-md-12">
                            <label for="password_confirmation">Confirm Password</label>
                            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Enter New password" value="" required="">
                        </div>
                        <div class="col-md-12 text-right mt-2">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Projects\Laravel\action_aid_ebook_api\resources\views/pages/users/user_create.blade.php ENDPATH**/ ?>