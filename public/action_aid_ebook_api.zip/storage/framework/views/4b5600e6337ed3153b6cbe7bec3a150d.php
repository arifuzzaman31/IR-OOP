

<?php $__env->startSection('content'); ?>
<div class="section m-4">
    <div class="widget widget-table-two">
        <div class="widget-heading">
            <h5 class="">User - List</h5>
        </div>
        <div class="widget-body">
            <div class="table-responsive">
                <table class="table table-striped datatable datatable_custom">
                    <thead>
                        <tr>
                            <th>
                                <div class="th-content text-left">ID</div>
                            </th>
                            <th>
                                <div class="th-content">Type</div>
                            </th>
                            <th>
                                <div class="th-content">Name</div>
                            </th>
                            <th>
                                <div class="th-content text-left">Phone</div>
                            </th>
                            <th>
                                <div class="th-content text-left">Email</div>
                            </th>
                            <th>
                                <div class="th-content text-left">Status</div>
                            </th>
                            <th>
                                <div class="th-content text-center">Action</div>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-left"><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->role_mave->title); ?></td>
                            <td>
                                <img src="<?php echo e(asset( $user->profile_pic_mave? $user->profile_pic_mave->file_path : 'media/default.png' )); ?>" height="75px" width="75px" class="img-thumbnail rounded-circle" alt="">
                                <?php echo e($user->firstname .' ' .$user->lastname); ?>

                            </td>
                            <td class="text-left"><?php echo e($user->phone); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td class="text-left"><?php echo e($user->status == 1 ? "Active" : "Inactive"); ?></td>
                            <td class="action_btn text-center">
                                <a href="<?php echo e(url('admin/user/edit/' . $user->id)); ?>" class="btn btn-sm btn-warning btn-small">
                                    <i class="fa fa-pencil"></i>
                                </a>
                                <a href="#" class="btn <?php echo e($user->status == 1 ? 'btn-danger' : 'btn-success'); ?> btn-sm btn-small ban-user" title="<?php echo e($user->status == 1 ? 'Disable' : 'Activate'); ?>" data-user-id="<?php echo e($user->id); ?>" data-user-status="<?php echo e($user->status); ?>">
                                    <i class="fa <?php echo e($user->status == 1 ? 'fa-ban' : 'fa-check-square-o'); ?>"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).on('click', '.ban-user', async function(e) {
        e.preventDefault();
        if (!confirm("Are you sure to disable this user?")) {
            return false;
        }

        let new_status = ($(this).attr('data-user-status') == 0) ? 1 : 0;
        let URL = "<?php echo e(url('admin/user/update')); ?>" + "/" + $(this).attr('data-user-id');

        let DATA = {
            status: new_status
        };

        let response = await custom_ajax('POST', URL, DATA);
        if (response.status == 200) {
            alert('User Updated Sucessfully');
        }

    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Projects\Laravel\action_aid_ebook_api\resources\views/pages/users/user_list.blade.php ENDPATH**/ ?>