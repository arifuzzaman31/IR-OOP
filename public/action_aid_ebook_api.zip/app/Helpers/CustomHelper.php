<?php

namespace App\Helpers;

use App\Models\Media;
use Illuminate\Support\Str;

class CustomHelper
{

    public function __construct()
    {
    }

    public static function upload_media_file($file)
    {
        $file_size = $file->getSize();

        // Generate a title based on the original file name
        $originalName = $file->getClientOriginalName();

        $title = pathinfo($originalName, PATHINFO_FILENAME);
        $generatedTitle = "mave_" . Str::random(6);

        // Rename the media
        $mediaName = $generatedTitle . '.' . $file->extension();

        // Move the file to the public/media directory
        $file->move(public_path('media'), $mediaName);

        // Create a new Media record in the database
        $media = Media::create([
            'title' => $originalName,
            'file_name' => $mediaName,
            'file_type' => $file->getClientMimeType(),
            'file_path' => 'media/' . $mediaName,
            'size' => $file_size
        ]);

        return $media;
    }

    public  static  function abbr_to_full_state($abbr)
    {

        $states = [
            'ebook_title' => 'Title',
            'ebook_date' => 'Date',

            // Study/Research/Article----Template 
            'ebook_abstract' => 'Abstract (200 word)',
            'ebook_intro' => 'Introduction and Objective (200 word)',
            'ebook_literature_review' => 'Literature Review (500 word)',
            'ebook_method' => 'Methodology (300 word)',
            'ebook_rd' => 'Results & Discussions including figures and tables (2000 word)',
            'ebook_cr' => 'Conclusion and Recommendations (300 word)',
            'ebook_reference' => 'References (500 word)',

            // Innovative Idea--- Template 
            'problem' => 'What is the problem?',
            'why_innovative' => 'Why is it innovative (200 word)?',
            'participants' => 'Who are the participants (100 word)?',
            'how_work' => 'How will it work (200 word)?',
            'look_like' => 'What will it look like (200 word)?',
            'benifits_participants' => 'What is the benefit for the participants (100 word)?',
            'benefit_organization' => 'What is the benefit for the organization (100 word)?',
            'scale_up' => 'How can be sustainable of your idea or scale up (100 word)?',

            // Case Story/Success Story---- Template 
            'introduction' => 'Introduction/Background (150 word)',
            'problem_solution' => 'Problem & Solution (300 word)',
            'organization_contribution' => 'Organization contribution (100 word)',
            'community_contribution' => 'Community contribution (100 word)',
            'sustain_success' => 'Sustainability of success (250 word)',
            'participants_quotes' => 'Participants quotes (100)',
            'action_photo' => 'Action photo (with caption)',

            // Case Story/Success Story---- Template 
            'problem' => 'Introduction/Background (150 word)',
            'key_achievement' => 'Key achievement (250 word)',
            'participants_benifited' => 'How participants benefited (200 word)',
            'strategy' => 'Which strategy have used (200 word)',
            'leason_learned' => 'What lessons learned generated (200 word)',
        ];

        $full_state = array_key_exists($abbr, $states) ? $states[$abbr] :  $abbr;

        return $full_state;
    }
}
