<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\EbookController;
use App\Http\Controllers\AdminLoginController;
use App\Http\Controllers\PublicationController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});



Route::get('login', function () {
    return view('admin.login');
});

Route::post('login', [AdminLoginController::class, 'login'])->name('login');
Route::view('forgot-password', 'admin.forgot_password')->name('forgot-password');
Route::post('send-reset-mail', [AdminLoginController::class, 'resetMail'])->name('send-reset-mail');
Route::get('enter-password', [AdminLoginController::class, 'enterPassword'])->name('reset.password.enter');
Route::post('enter-password', [AdminLoginController::class, 'store'])->name('reset.password.enter');


Route::get('/dashboard', function () {
    if (Auth::check()) {
        return redirect(url('admin/dashboard'));
    } else {
        return redirect(url('login'));
    }
});



Route::redirect('/', 'admin/dashboard');
// Route::get('/me', [AdminLoginController::class, 'getUser']);
// Route::get('/dashboard', [AdminLoginController::class, 'index']);
// Route::get('logout', [AdminLoginController::class, 'logout'])->name('logout');
// Route::view('change-password', 'admin.change_password')->name('change-password');
// Route::post('change-password', [AdminLoginController::class, 'changePassword']);




// User - Working Here
Route::get('/users', [UserController::class, 'index']);
Route::get('/users/{id}', [UserController::class, 'index']);
// Route::get('/users/{order?}/{pagination?}', [UserController::class, 'index']);
// Route::get('/users/{order}', [UserController::class, 'index']);
Route::post('/users', [UserController::class, 'store']);
Route::put('/users/{id}', [UserController::class, 'update']);
Route::delete('/users/{id}', [UserController::class, 'destroy']);



// Publication
// Route::get('/ebook', [EbookController::class, 'index']);
// Route::get('/ebook/{id}', [EbookController::class, 'index']);
// Route::post('/ebook', [EbookController::class, 'store']);
// Route::put('/ebook/{id}', [EbookController::class, 'update']);
// Route::delete('/ebook/{id}', [EbookController::class, 'destroy']);


// Publication
Route::get('/publication', [PublicationController::class, 'index']);
Route::get('/publication/{id}', [PublicationController::class, 'index']);
Route::post('/publication', [PublicationController::class, 'store']);
Route::put('/publication/{id}', [PublicationController::class, 'update']);
Route::delete('/publication/{id}', [PublicationController::class, 'destroy']);


// Action Aid URLs
// Route::get('/users', [DemoController::class, 'users']);
// Route::get('/users/{type}', [DemoController::class, 'users']);


// Route::get('/ebooks', [DemoController::class, 'ebooks']);
// Route::get('/ebook/create/{type}', [DemoController::class, 'ebook_templete']);

// Route::get('/settings', [DemoController::class, 'settings']);
