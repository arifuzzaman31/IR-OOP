<?php 
require_once 'core/init.php';
		
		//echo config::get('mysql/host');
			$user = DB::getInstance()->query('SELECT * FROM users'); //for query
			// $user = DB::getInstance()->update('users', 3, array(
			// 	'username' => 'rashid',
			// 	'password' => '456',
			// 	'salt' => 'salt',
			// 	'name' => 'Harun',
			// 	'joined' => '2018-22-10'
			// )); //for INSERT
		// $user = DB::getInstance();
		// $user->get('users', array('username','=','arif'));
		//$user =  DB::getInstance()->get('users', array('username','=','arif'));

		// if ($user) {
		// 	echo $user;
		// } 
		// else {
		// 	//foreach ($user->results() as $us) {
		// 		echo "updated" ;
		// 	}
				

?>