<?php 
	require_once 'core/init.php';

	if (Input::exists()) {

		//echo Input::get('uname');
			$validate = new Validate();
			$validation = $validate->check($_POST, array(
				'username' => array(
					'required' => true,
					'min' => 3,
					'max' => 20,
					'unique' => 'users'
				),
				'password' => array(
					'required' => true,
					'min' => 6
				),
				'password_again' => array(
					'required' => true,
					'matches' => 'password'
				),
				'name' => array(
					'required' => true,
					'min' => 2,
					'max' => 50
				)
			)); 
	if ($validation->passed()) {
			echo 'passed';
	}
	else {
			print_r($validation->errors());
	} 
}
 ?>

<style type="text/css">
	form{
		margin: 50px;
		padding: 30px;
		border: 1px solid #000000;
	}
	.fields{
		margin-top: 10px;
	}

</style>

<form method="POST" action="">

	<div class="fields">
		<label for="username">Username :</label>
		<input type="text" name="username" id="username" value="" autocomplete="off">
	</div>
	
	<div class="fields">
		<label for="password">password :</label>
		<input type="password" name="password" id="password">
	</div>

	<div class="fields">
		<label for="password_again">Confirm password :</label>
		<input type="text" name="password_again" id="password_again">
	</div>

		<input type="submit" name="name" value="Register" >
	
</form>